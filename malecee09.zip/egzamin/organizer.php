<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Organizer</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
<?php
        if(isset($_POST['wydarzenie'])) {
            $host = 'localhost';
            $user = 'root';
            $pass = '';
            $database = 'egzamin6';
            $con = mysqli_connect($host,$user,$pass,$database);
            $wydarzenie = $_POST['wydarzenie'];
            $sql = "UPDATE zadania SET wpis = '$wydarzenie' WHERE dataZadania = '2020-08-27'";
            $con->query($sql);
            $con->close();
        }
    ?>
    <div id="baner">
        <div id="baner1">
            <h2>MÓJ ORGANIZER</h2>
        </div>
        <div id="baner2">
            <form action="organizer.php" method="post">
                Wpis wydarzenia: <input type="text">
                <input type="submit" value="ZAPISZ">
            </form>
        </div>
        <div id="baner3">
            <img src="logo2.png" alt="Mój organizer">
        </div>
    </div>
    <div id="glowny">
    <?php
        $sql = "SELECT dataZadania, miesiac, wpis FROM `zadania` WHERE miesiac = 'sierpien'";
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $database = 'egzamin6';
        $con = mysqli_connect($host,$user,$pass,$database);
        $result = $con->query($sql);
        while($row = $result->fetch_assoc()) {
            $data = $row['dataZadania'];
            $miesiac = $row['miesiac'];
            $wpis = $row['wpis'];
            echo '<div>';
            echo "<h6>$data, $miesiac</h6>";
            echo "<p>$wpis</p>";
            echo '</div>';
        }
    ?>
    </div>
    <div id="stopka">
        <?php
            $sql = "SELECT miesiac, rok FROM `zadania` WHERE dataZadania = '2020-08-01'";
            $result = $con->query($sql);
            $row = $result->fetch_assoc();
            $miesiac = $row['miesiac'];
            $rok = $row['rok'];
            echo "<h1>miesiąc: $miesiac, rok: $rok</h1>";
            $con->close();
        ?>
        <p>Stronę wykonał Oskar Malec 4G</p>
    </div>
</body>
</html>